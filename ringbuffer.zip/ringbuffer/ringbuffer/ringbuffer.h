#pragma once

#include <vector>
#include <stdexcept>
#include <utility>
#include <condition_variable>

template <typename T>
class RingBuffer {
public:
	explicit RingBuffer(size_t capacity)
		: m_buffer(capacity),
		m_capacity(capacity),
		m_head(0),
		m_tail(0),
		m_size(0)
	{
	}

	void push(const T& item);
	T pop();

	bool empty() const;
	bool full() const;
	size_t size() const;
	size_t capacity() const noexcept;

private:
	std::vector<T>		m_buffer;
	const size_t		m_capacity;
	size_t				m_head;
	size_t				m_tail;
	std::atomic<size_t> m_size;

	mutable std::mutex		 m_mutex;
	std::condition_variable  m_not_empty;
	std::condition_variable  m_not_full;
};

#include "ringbuffer.tpp"
